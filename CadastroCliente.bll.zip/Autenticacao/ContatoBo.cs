﻿using CadastroCliente.DAL;
using CadastroCliente.Entities;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CadastroCliente.bll.Autenticacao
{
    public class ContatoBo
    {
        private ContatoDao _contatoDao;

        public List<Contato> ObterTodosOsJogos()
        {
            _contatoDao = new ContatoDao();

            return _contatoDao.ObterContatoPeloCadastro();
        }

    }
}
