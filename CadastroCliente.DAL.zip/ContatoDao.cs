﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CadastroCliente.Entities;
using System.Data.SqlClient;


namespace CadastroCliente.DAL
{
    public class ContatoDao
    {
        public Contato ObterContatoPeloCadastro(string nome, DateTime dataNascimento)
        {
            try
            {
                Conexao.conectar();
                SqlCommand command = new SqlCommand();
                command.Connection = Conexao.connection;
                
                    command.CommandText = "SELECT * FROM CONTATOS WHERE CONTATO = @NOME AND DATANASCIMENTO = @DATANASCIMENTO";

                    command.Parameters.AddWithValue("@NOME", nome);
                    command.Parameters.AddWithValue("@DATANASCIMENTO", dataNascimento);

                    Conexao.conectar();

                    var reader = command.ExecuteReader();

                Contato contato = null;

                    while (reader.Read())
                    {
                        contato = new Contato();
                        contato.Nome = reader["nome"].ToString();
                        contato.DataNascimento = Convert.ToDateTime(reader["dataNascimento"]);
                        
                    }

                    return contato;
                }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                Conexao.desconectar();
            }

        }
    }
}
