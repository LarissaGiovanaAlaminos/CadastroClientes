﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace CadastroCliente.DAL
{
    public class Conexao
    {
         static string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["ConexaoSQLServer"].ConnectionString;
        public static SqlConnection connection = new SqlConnection(connectionString);

        public static void conectar()
        {
            if (connection.State == System.Data.ConnectionState.Closed)
            {
                connection.Open();
            }
        }

        public static void desconectar()
        {
            if (connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}
